<?php
/**
 * Plugin Name: sulus.ai
 * Description: A basic plugin to load the sulus.ai widget script on all front-end pages.
 * Version: 1.0
 * Author: sulus.ai
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

function sulusai_enqueue_script() {
    wp_enqueue_script(
        'sulusai-widget-js',
        plugin_dir_url( __FILE__ ) . 'assets/widget.js',
        array(),
        '1.0',
        true // Load in footer
    );
}
add_action( 'wp_enqueue_scripts', 'sulusai_enqueue_script' );
